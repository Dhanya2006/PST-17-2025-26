/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
public class Main {
    public static void main(String[] args) {
        int num1 = 20;
        int num2 = 10;
        System.out.println("num1 + num2 :" +(num1+num2));
        System.out.println("num1 - num2 :" +(num1-num2));
        System.out.println("num1 * num2 :" +(num1*num2));
        System.out.println("num1 / num2 :" +(num1/num2));
        System.out.println("num1 % num2 :" +(num1%num2));
    }
}